export class User{
    static email: string;
    static password: string;
    
    constructor(public id:number,email:string="",password:string="")
    {

    }


}
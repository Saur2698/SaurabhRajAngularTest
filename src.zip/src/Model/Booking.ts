import { Room } from "./room";
import { User } from "./user";

export class Booking{
    
    constructor(public id:number,room:Room,user:User,purpose:string,participants:number)
    {

    }


}